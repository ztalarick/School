function handleFormSubmit() {
	// Get values of inputs
	// Pass values to addNewPost()
    var uname = document.getElementById("input-name").value;
    var email = document.getElementById("input-email").value;
    var frequency = document.getElementById("input-frequency").value;
    window.alert("Okay, " + uname + ", your email " + email + " will receive our newsletter " + frequency + " .")
}
document.getElementById("agreeterms").addEventListener("change", function(event){
    var checkbox = event.target;
    console.log(event);
    var val = checkbox.checked;
    console.log(val)
    document.getElementById("submitbutton").disabled = !val;
    console.log(document.getElementById("submitbutton"))
})