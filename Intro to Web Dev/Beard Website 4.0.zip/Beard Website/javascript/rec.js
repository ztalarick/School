document.getElementById("my1").addEventListener("click", function(){
    alert("Roosters: \n 610 Washington Street \n Hoboken, NJ 07030 \n (201) 683-9970");
});
document.getElementById("my2").addEventListener("click", function(){
    alert("The Hoboken Man: \n 1150 Maxwell Lane \n Hoboken, NJ 07030 \n (201) 610-0500");
});
document.getElementById("my3").addEventListener("click", function(){
    alert("V's Barbershop \n 1114 Washington St \n Hoboken, NJ 07030 \n (201) 942-9559");
});
document.getElementById("my4").addEventListener("click", function(){
    alert("Hoboken Hair For Men \n 115 Washington Street \n Hoboken, NJ 07030 \n (201) 253-0380");
});
