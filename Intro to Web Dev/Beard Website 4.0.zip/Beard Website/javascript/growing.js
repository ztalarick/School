function reset(){
    document.getElementById("choose").style.display = "none";
    document.getElementById("1").classList.remove("active");

    document.getElementById("noshave").style.display = "none";
    document.getElementById("2").classList.remove("active");
    
    document.getElementById("myths").style.display = "none";
    document.getElementById("3").classList.remove("active");
    
    document.getElementById("shave").style.display = "none";
    document.getElementById("4").classList.remove("active");
    
    document.getElementById("GG").style.display = "none";
    document.getElementById("5").classList.remove("active");
    
}

function display(divID){
    if (divID == choose){
        document.getElementById("choose").style.display = "block";   
        document.getElementById("1").classList.add("active");
    }
    if (divID == noshave){
        document.getElementById("noshave").style.display = "block";
        document.getElementById("2").classList.add("active");
    }
    if (divID == myths){
        document.getElementById("myths").style.display = "block";   
        document.getElementById("3").classList.add("active");
    }
    if (divID == shave){
        document.getElementById("shave").style.display = "block";
        document.getElementById("4").classList.add("active");
    }
    if (divID == GG){
        document.getElementById("GG").style.display = "block";
        document.getElementById("5").classList.add("active");
    }
}

