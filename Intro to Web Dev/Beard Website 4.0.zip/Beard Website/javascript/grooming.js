function handleFormSubmit(){
if(window.event) window.event.preventDefault();
var body = document.getElementsByTagName('body')[0];
if (inputinches.value=='lessthanone')
body.style.backgroundColor = "#cd7f32";
if (inputinches.value=='lessthantwo')
body.style.backgroundColor = "#C0C0C0";
if (inputinches.value=="overtwo")
body.style.backgroundColor = "#FFD700";
replacemembership();
}
function replacemembership(){
if (inputinches.value=='lessthanone')
membership.innerHTML='You are considered a bronze member in the beard community'
if (inputinches.value=='lessthantwo')
membership.innerHTML='You are considered a silver member in the beard community'
if (inputinches.value=='overtwo')
membership.innerHTML='You are considered a gold member in the beard community'
}