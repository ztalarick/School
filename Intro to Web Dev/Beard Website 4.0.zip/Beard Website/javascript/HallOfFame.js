function newest()
{
    document.getElementById("Marx").style.order = "4";
    document.getElementById("MLink").style.order = "4";
    document.getElementById("Burnside").style.order = "3";
    document.getElementById("BLink").style.order = "3";
    document.getElementById("Langseth").style.order = "2";
    document.getElementById("LLink").style.order = "2";
    document.getElementById("Dali").style.order = "1";
    document.getElementById("DLink").style.order = "1";
}
function oldest()
{
    document.getElementById("Marx").style.order = "1";
    document.getElementById("MLink").style.order = "1";
    document.getElementById("Burnside").style.order = "2";
    document.getElementById("BLink").style.order = "2";
    document.getElementById("Langseth").style.order = "3";
    document.getElementById("LLink").style.order = "3";
    document.getElementById("Dali").style.order = "4";
    document.getElementById("DLink").style.order = "4";
}
function alphafirst()
{
    document.getElementById("Burnside").style.order = "1";
    document.getElementById("BLink").style.order = "1";
    document.getElementById("Langseth").style.order = "2";
    document.getElementById("LLink").style.order = "2";
    document.getElementById("Marx").style.order = "3";
    document.getElementById("MLink").style.order = "3";
    document.getElementById("Dali").style.order = "4";
    document.getElementById("DLink").style.order = "4";
}
function alphalast()
{
    document.getElementById("Burnside").style.order = "1";
    document.getElementById("BLink").style.order = "1";
    document.getElementById("Dali").style.order = "2";
    document.getElementById("DLink").style.order = "2";
    document.getElementById("Langseth").style.order = "3";
    document.getElementById("LLink").style.order = "3";
    document.getElementById("Marx").style.order = "4";
    document.getElementById("MLink").style.order = "4";
}
function longest()
{
    document.getElementById("Langseth").style.order = "1";
    document.getElementById("LLink").style.order = "1";
    document.getElementById("Marx").style.order = "2";
    document.getElementById("MLink").style.order = "2";
    document.getElementById("Burnside").style.order = "3";
    document.getElementById("BLink").style.order = "3";
    document.getElementById("Dali").style.order = "4";
    document.getElementById("DLink").style.order = "4";
}
function shortest()
{
    document.getElementById("Langseth").style.order = "4";
    document.getElementById("LLink").style.order = "4";
    document.getElementById("Marx").style.order = "3";
    document.getElementById("MLink").style.order = "3";
    document.getElementById("Burnside").style.order = "2";
    document.getElementById("BLink").style.order = "2";
    document.getElementById("Dali").style.order = "1";
    document.getElementById("DLink").style.order = "1";
}

function sort()
{
    var s = document.getElementById("sort").value;
    if(s == "Newest")
	newest();
    if(s == "Oldest")
	oldest();
    if(s == "AlphabetFirst")
	alphafirst();
    if(s == "AlphabetLast")
	alphalast();
    if(s == "Longest")
	longest();
    if(s == "Shortest")
	shortest();
}